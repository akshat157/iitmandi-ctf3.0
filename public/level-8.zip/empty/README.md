Help for CTF
This repo might help you in other questions of CTFs. :P
Don't Find stegsolve :P
